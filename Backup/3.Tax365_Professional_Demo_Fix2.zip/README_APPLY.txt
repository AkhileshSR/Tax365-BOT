TAX365 PROFESSIONAL DEMO — FIX PACK 2

Files to replace:
  app/query_router.py
  app/tax_service.py

No changes are required to:
  app/response_formatter.py
  app/telegram_bot.py

FIXES INCLUDED
1. Overdue filings: default report returns every matching overdue record and states total count versus displayed count.
2. Country audit routing: audit/litigation intent is evaluated before legal-entity output keywords, preventing India audit questions from returning the entity register.
3. Exposure threshold: reports count every matching case, then clearly disclose how many are displayed (top exposure first).
4. Audit stage descriptions: reads a description field only if one exists; otherwise explicitly says the supplied reference data does not separately record descriptions.

VALIDATION AGAINST THE SUPPLIED CSV DATA
- Overdue records: 60 total; 60 displayed.
- India audit cases: 2; routed to audit register.
- Cases above USD 1 million: 103 total; top 10 displayed with completeness disclosure.
- Audit stages: all 5 exact source names; descriptions correctly disclosed as not separately recorded.
- Python syntax compilation: passed.

APPLY
1. Stop the running bot with Ctrl+C.
2. Back up the current app/query_router.py and app/tax_service.py.
3. Extract this ZIP into your T365_Solution project directory, preserving the app folder.
4. Run:
     python -m py_compile .\app\query_router.py .\app\tax_service.py
     python validate_fix.py ..\data
5. If validation passes, start:
     python main.py

Do not replace .env, the database, CSV data, or other application modules.

DATA NOTE
The dataset is synthetic and illustrative. The audit stage reference CSV contains only stage_order and stage_name; it has no separate description field. This update does not invent descriptions.
