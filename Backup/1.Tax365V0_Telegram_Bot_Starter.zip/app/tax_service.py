"""
Purpose: Deterministic tax data retrieval. Financial figures are read from SQLite.
Sample input: Country name, tax type, threshold or user question.
Output: Verified text results or an explicit not-found response.
Dependencies: sqlite3, re.
Architecture: query_router -> tax_service -> SQLite -> response_formatter.
"""

import re
import sqlite3

NOT_FOUND = "Data not found in the tracking registry."

def _rows(connection: sqlite3.Connection, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
    """Execute a parameterized read-only query and return rows."""
    return connection.execute(sql, params).fetchall()

def global_summary(connection: sqlite3.Connection) -> str:
    """Summarize loaded registry counts and compliance status counts."""
    entities = connection.execute("SELECT COUNT(*) FROM legal_entities").fetchone()[0]
    countries = connection.execute("SELECT COUNT(*) FROM country_master").fetchone()[0]
    filings = connection.execute("SELECT COUNT(*) FROM tax_compliance").fetchone()[0]
    audits = connection.execute("SELECT COUNT(*) FROM tax_audits").fetchone()[0]
    statuses = _rows(connection, "SELECT filing_status, COUNT(*) AS n FROM tax_compliance GROUP BY filing_status ORDER BY filing_status")
    lines = ["**Global Tax Registry Summary**",
             f"* Countries in implementation master: {countries}",
             f"* Legal entity records: {entities}",
             f"* Compliance records: {filings}",
             f"* Audit / litigation records: {audits}",
             "* Filing status breakdown:"]
    lines.extend([f"  * {r['filing_status']}: {r['n']}" for r in statuses])
    return "\n".join(lines)

def overdue_filings(connection: sqlite3.Connection, limit: int = 30) -> str:
    """Return overdue filing records ordered by due date."""
    rows = _rows(connection, """
        SELECT country, legal_entity_id, tax_type, tax_period, statutory_due_date, filing_status
        FROM tax_compliance WHERE filing_status = ?
        ORDER BY statutory_due_date LIMIT ?
    """, ("Overdue", limit))
    if not rows:
        return NOT_FOUND
    lines = ["**Overdue Tax Filings**"]
    for row in rows:
        lines.append(f"* {row['country']} | {row['tax_type']} | {row['tax_period']} | Due: {row['statutory_due_date']} | {row['legal_entity_id']}")
    return "\n".join(lines)

def high_exposure_audits(connection: sqlite3.Connection, threshold_usd: float = 1_000_000, limit: int = 30) -> str:
    """List disputes above a USD threshold using the explicit USD exposure field."""
    rows = _rows(connection, """
        SELECT country, dispute_type, current_stage, current_phase, case_id,
               financial_risk_amount_usd, financial_risk_currency, case_status
        FROM tax_audits
        WHERE UPPER(financial_risk_currency) = 'USD'
          AND CAST(financial_risk_amount_usd AS REAL) > ?
        ORDER BY CAST(financial_risk_amount_usd AS REAL) DESC LIMIT ?
    """, (threshold_usd, limit))
    if not rows:
        return NOT_FOUND
    lines = [f"**Tax Audits Above ${threshold_usd:,.0f} USD**"]
    for row in rows:
        amount = float(row["financial_risk_amount_usd"])
        lines.append(
            f"* **{row['country']} – {row['dispute_type']}** ({row['case_id']})"
            f"\n  * Stage: {row['current_stage']}"
            f"\n  * Phase: {row['current_phase']}"
            f"\n  * Financial risk: ${amount:,.2f} USD"
            f"\n  * Case status: {row['case_status']}"
        )
    return "\n".join(lines)

def country_entity_profile(connection: sqlite3.Connection, country: str) -> str:
    """Retrieve all legal entity profiles for an exact country-name match."""
    rows = _rows(connection, """
        SELECT country, legal_entity_name, legal_entity_id, le_level, entity_status,
               local_tax_id, vat_gst_registration_id, managing_director_1,
               managing_director_2, functional_currency, direct_parent_name
        FROM legal_entities WHERE LOWER(country) = LOWER(?) ORDER BY legal_entity_id
    """, (country,))
    if not rows:
        return NOT_FOUND
    lines = [f"**Entity Profile: {country}**"]
    for row in rows:
        lines.extend([
            f"* **Legal Entity:** {row['legal_entity_name']}",
            f"* **LE ID:** {row['legal_entity_id']}",
            f"* **LE Level:** {row['le_level']}",
            f"* **Status:** {row['entity_status']}",
            f"* **Tax ID:** {row['local_tax_id']}",
            f"* **VAT/GST ID:** {row['vat_gst_registration_id']}",
            f"* **Managing Directors:** {row['managing_director_1']}, {row['managing_director_2']}",
            f"* **Functional Currency:** {row['functional_currency']}",
            f"* **Parent:** {row['direct_parent_name']}",
            ""
        ])
    return "\n".join(lines).strip()

def country_compliance(connection: sqlite3.Connection, country: str, tax_keyword: str = "") -> str:
    """Return compliance rows for a country, optionally filtered by tax keyword."""
    sql = """SELECT country, legal_entity_id, tax_type, tax_period, statutory_due_date,
                    filing_status, submission_date, approval_date, uploaded_by,
                    proof_available, artifact_filename
             FROM tax_compliance WHERE LOWER(country) = LOWER(?)"""
    params: tuple = (country,)
    if tax_keyword:
        sql += " AND (LOWER(tax_type) LIKE ? OR LOWER(tax_code) LIKE ?)"
        params += (f"%{tax_keyword.lower()}%", f"%{tax_keyword.lower()}%")
    sql += " ORDER BY statutory_due_date"
    rows = _rows(connection, sql, params)
    if not rows:
        return NOT_FOUND
    lines = [f"**Compliance Status: {country}**"]
    for row in rows:
        lines.append(
            f"* **Tax:** {row['tax_type']} ({row['tax_period']})"
            f"\n  * Filing Status: {row['filing_status']}"
            f"\n  * Due Date: {row['statutory_due_date']}"
            f"\n  * Submission Date: {row['submission_date'] or 'Not recorded'}"
            f"\n  * Approval Date: {row['approval_date'] or 'Not recorded'}"
            f"\n  * Proof Available in index: {row['proof_available']}"
            f"\n  * Artifact: {row['artifact_filename'] or 'Not recorded'}"
        )
    return "\n".join(lines)

def country_audits(connection: sqlite3.Connection, country: str) -> str:
    """List audit and litigation records for one country."""
    rows = _rows(connection, """
        SELECT case_id, dispute_type, current_stage, current_phase, case_status,
               financial_risk_amount_usd, financial_risk_currency
        FROM tax_audits WHERE LOWER(country) = LOWER(?)
        ORDER BY CAST(financial_risk_amount_usd AS REAL) DESC
    """, (country,))
    if not rows:
        return NOT_FOUND
    lines = [f"**Tax Audits & Litigations: {country}**"]
    for row in rows:
        amount = row["financial_risk_amount_usd"]
        currency = row["financial_risk_currency"]
        amount_text = f"{float(amount):,.2f} {currency}" if amount else "Not recorded"
        lines.append(f"* {row['case_id']} | {row['dispute_type']} | {amount_text}\n  * {row['current_stage']}\n  * {row['current_phase']}\n  * Status: {row['case_status']}")
    return "\n".join(lines)
