"""
Purpose: Telegram polling interface, commands, authorization and document delivery.
Sample input: Telegram message /start, /whoami or a tax question.
Output: Executive response or verified PDF sent to the Telegram user.
Dependencies: python-telegram-bot, config.py, database.py, security.py and services.
Architecture: Telegram -> authorization -> deterministic router -> AnythingLLM fallback -> Telegram.
"""

import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
from .config import Settings
from .database import connect_db, log_event
from .security import is_authorized
from .query_router import route_question
from .anythingllm_client import ask_anythingllm
from .response_formatter import split_telegram_message
from .artifact_service import find_local_artifact

logger = logging.getLogger(__name__)

def _get_connection(settings: Settings):
    """Open a short-lived SQLite connection for one update."""
    return connect_db(settings.database_path)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Explain the bot and show the caller's Telegram numeric ID for allowlisting."""
    user = update.effective_user
    await update.message.reply_text(
        "Tax365 – Global Tax Intelligence Assistant\n\n"
        f"Your Telegram user ID: {user.id}\n"
        "An administrator must add this ID to ALLOWED_TELEGRAM_USER_IDS in .env "
        "before you can query tax records.\n\nUse /whoami to display this ID again."
    )

async def whoami_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Return the Telegram numeric user ID without exposing tax data."""
    await update.message.reply_text(f"Telegram user ID: {update.effective_user.id}")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process an incoming text question.
    Input: Telegram Update and bot context.
    Output: Deterministic database response or AnythingLLM fallback.
    """
    settings: Settings = context.application.bot_data["settings"]
    user = update.effective_user
    question = (update.message.text or "").strip()

    if not is_authorized(user.id if user else None, settings):
        await update.message.reply_text("Access denied. Your Telegram account is not on the approved user list.")
        return

    connection = _get_connection(settings)
    try:
        answer = route_question(connection, question)
        if answer is None:
            try:
                answer = await ask_anythingllm(question, settings, session_id=f"telegram-{user.id}")
            except Exception:
                logger.exception("AnythingLLM request failed")
                answer = "The conversational AI service is currently unavailable. Structured tax queries remain available."
        log_event(connection, user.id, "QUESTION", question, answer[:1500])

        # A filename alone is not sufficient. Send only a verified local PDF.
        # Current synthetic dataset contains metadata, not actual PDF binaries.
        if "proof" in question.lower() or "receipt" in question.lower() or "artifact" in question.lower():
            # Artifact sending is intentionally not guessed from a response.
            # Country/tax-specific retrieval is added after user scope enforcement is configured.
            pass

        for chunk in split_telegram_message(answer):
            await update.message.reply_text(chunk)
    finally:
        connection.close()

def build_application(settings: Settings) -> Application:
    """
    Construct the Telegram application and register command handlers.
    Input: validated Settings.
    Output: configured python-telegram-bot Application.
    """
    application = Application.builder().token(settings.telegram_bot_token).build()
    application.bot_data["settings"] = settings
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("whoami", whoami_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    return application
