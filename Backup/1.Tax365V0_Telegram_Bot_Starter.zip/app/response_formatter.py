"""
Purpose: Apply Telegram-safe message length and executive response conventions.
Sample input: Service response string.
Output: One or more Telegram-sized text chunks.
Dependencies: textwrap.
Architecture: tax_service / AnythingLLM -> formatter -> Telegram.
"""

def split_telegram_message(message: str, max_length: int = 3900) -> list[str]:
    """
    Split a long response without exceeding Telegram's message length.
    Input: message and maximum chunk length.
    Output: Ordered list of text chunks.
    """
    if len(message) <= max_length:
        return [message]
    chunks, current = [], ""
    for line in message.splitlines():
        if len(current) + len(line) + 1 > max_length and current:
            chunks.append(current)
            current = ""
        current += ("\n" if current else "") + line
    if current:
        chunks.append(current)
    return chunks
