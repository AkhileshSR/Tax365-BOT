"""
Purpose: Route common executive questions to deterministic tax services.
Sample input: "Show high-risk audits over $1 million."
Output: A service result, or None when the question needs conversational RAG.
Dependencies: re, sqlite3, tax_service.py.
Architecture: Telegram -> query_router -> tax_service OR AnythingLLM fallback.
"""

import re
import sqlite3
from . import tax_service

COUNTRIES = [
    "United Kingdom","Germany","France","Netherlands","Belgium","Spain","Italy","Poland",
    "Switzerland","Sweden","Norway","Denmark","Ireland","South Africa","Kenya","Nigeria",
    "Egypt","United Arab Emirates","Saudi Arabia","Turkey","Portugal","Austria",
    "United States","Canada","Mexico","China","Japan","South Korea","Taiwan","Hong Kong",
    "Mongolia","Guatemala","Costa Rica","Panama","Colombia","Venezuela","Dominican Republic",
    "Brazil","Argentina","Chile","Peru","Uruguay","Paraguay","Ecuador","Bolivia","India",
    "Singapore","Australia","New Zealand","Thailand","Vietnam","Malaysia","Indonesia",
    "Philippines","Pakistan","Bangladesh","Sri Lanka","Cambodia","Myanmar","Laos"
]

def _find_country(question: str) -> str | None:
    """Find the longest exact country-name mention from the configured country list."""
    lowered = question.lower()
    matches = [country for country in COUNTRIES if country.lower() in lowered]
    return max(matches, key=len) if matches else None

def route_question(connection: sqlite3.Connection, question: str) -> str | None:
    """
    Identify a supported deterministic query and execute it.
    Input: SQLite connection and user question.
    Output: Formatted verified answer, or None for AnythingLLM fallback.
    """
    q = question.lower()
    country = _find_country(question)

    if any(term in q for term in ["global summary", "global dashboard", "across all 60", "global tax compliance summary"]):
        return tax_service.global_summary(connection)

    if ("audit" in q or "dispute" in q or "litigation" in q) and any(x in q for x in ["$1 million", "1 million", "1000000", "high-risk", "high risk", "above"]):
        threshold = 1_000_000.0
        match = re.search(r"\$?\s*([\d,.]+)\s*(million|m)?", q)
        if match and ("million" in (match.group(2) or "") or (match.group(2) or "") == "m"):
            threshold = float(match.group(1).replace(",", "")) * 1_000_000
        elif match and float(match.group(1).replace(",", "")) >= 1000:
            threshold = float(match.group(1).replace(",", ""))
        return tax_service.high_exposure_audits(connection, threshold)

    if ("overdue" in q or "past due" in q) and any(x in q for x in ["filing", "return", "tax", "compliance"]):
        return tax_service.overdue_filings(connection)

    if country and any(x in q for x in ["entity profile", "subsidiary", "legal entit", "entities", "tax registration", "directors"]):
        return tax_service.country_entity_profile(connection, country)

    if country and any(x in q for x in ["filing", "compliance", "cit", "vat", "gst", "withholding", "wht", "return", "proof", "receipt", "artifact"]):
        keyword = ""
        if "cit" in q or "corporate income tax" in q:
            keyword = "CIT"
        elif "vat" in q:
            keyword = "VAT"
        elif "gst" in q:
            keyword = "GST"
        elif "withholding" in q or "wht" in q:
            keyword = "WHT"
        return tax_service.country_compliance(connection, country, keyword)

    if country and any(x in q for x in ["audit", "dispute", "litigation", "tax controversy"]):
        return tax_service.country_audits(connection, country)

    return None
