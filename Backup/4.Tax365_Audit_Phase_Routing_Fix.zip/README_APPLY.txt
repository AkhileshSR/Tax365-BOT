Tax365 audit-phase routing fix

Files:
- app/query_router.py (replacement)
- VALIDATION_REPORT.txt

Apply:
1. Stop the Telegram bot with Ctrl+C.
2. Back up the current app/query_router.py.
3. Replace only app/query_router.py with the file in this package.
4. Do not replace app/tax_service.py; the existing audit_phase_reference()
   function already retrieves the phases in source-defined order.
5. Run:
   python -m py_compile .\\app\\query_router.py
6. Restart:
   python main.py
7. Test in Telegram:
   Show all seven audit phases in sequence, including their exact names.

No CSV, database, .env, or other application files need to be changed.
