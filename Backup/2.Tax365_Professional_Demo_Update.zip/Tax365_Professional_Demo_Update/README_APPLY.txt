# Tax365 Professional Demo Bot – Targeted Update

## Scope
This update replaces only four existing application modules:
- `app/tax_service.py`
- `app/query_router.py`
- `app/response_formatter.py`
- `app/telegram_bot.py`

It does not replace `config.py`, `database.py`, `data_loader.py`, `security.py`, `artifact_service.py`, `.env`, the SQLite database, or the CSV source data.

## Apply safely
1. Stop the bot with `Ctrl+C`.
2. Back up the current four files.
3. Copy the four files in this package's `app` folder into the existing project's `app` folder, overwriting those four files only.
4. Do not overwrite `.env` or any CSV files.
5. Run the regression smoke test commands below.

## PowerShell commands
Run from:
`D:\JaiShriHanu\TheGardenPlan\7.MY_PRODUCT\Tax365V0\1_BOT\T365_Solution`

```powershell
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
New-Item -ItemType Directory -Force ".\Backup\pre_demo_$stamp" | Out-Null
Copy-Item ".\app\tax_service.py" ".\Backup\pre_demo_$stamp\"
Copy-Item ".\app\query_router.py" ".\Backup\pre_demo_$stamp\"
Copy-Item ".\app\response_formatter.py" ".\Backup\pre_demo_$stamp\"
Copy-Item ".\app\telegram_bot.py" ".\Backup\pre_demo_$stamp\"

# Extract the supplied ZIP to a temporary folder, then copy only:
Copy-Item ".\Tax365_Professional_Demo_Update\app\*.py" ".\app\" -Force
```

If you extract the ZIP elsewhere, adjust the source folder in the final `Copy-Item` command.

## Start and test
```powershell
python -m compileall .\app
python main.py
```

In Telegram:
- `/start`
- `/help`
- `/whoami`
- Then test the 13 registry questions from the acceptance list supplied with this update.

## Implemented
- Global compliance summary with percentages.
- Regional compliance summary.
- Multi-country compliance comparison.
- Global CIT filing counts by country and status.
- Overdue filings with legal entity name and status.
- Global audit exposure by region.
- Top-N audit ranking with enforced limit.
- Threshold-based audit exposure reports.
- Country legal entity register including company registration ID.
- Country audit reports with authority, entity and next action.
- Exact audit-stage and audit-phase reference outputs.
- Artifact-index lookup that distinguishes metadata from actual PDF files.
- `/help` command and consistent synthetic-demo disclaimer.
- Safer Telegram message splitting and improved error handling.

## Data and security caveats
- The supplied CSVs are synthetic illustrative data. Do not present them as actual client records.
- Artifact index entries say `Metadata only - PDF not included`; the bot therefore does not claim to send a PDF.
- Keep the Telegram bot token private. Do not place it in source code, screenshots, or client materials.
- `ALLOWED_TELEGRAM_USER_IDS` remains the access-control mechanism in this starter version. It is not enterprise SSO/RBAC.
- AnythingLLM remains optional. Financial amounts, filing counts and status totals are computed from SQLite.
